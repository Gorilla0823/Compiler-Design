/*test for float,arithmetic computation,and printf*/ 
void main()
{
   float a;
   float b;
   a=2.0;
   b=7.0*a+1.3;
   printf("---The result of test2.c---\n");
   printf("I like to eat %f or %f bananas\n",a,b);
   printf("The number of bananas won't be floating-points,OK?\n");
   printf("------------END------------\n");
}
