/*test for int,arithmetic computation,and printf*/ 
void main()
{
   int a;
   int b;
   a = 2;
   b = a+2*(1+(-100));
   printf("---The result of test1.c---\n");
   printf("I like to eat %d or %d bananas\n",b,a);
   printf("The number of bananas won't be negative,OK?\n");
   printf("------------END------------\n");
}
